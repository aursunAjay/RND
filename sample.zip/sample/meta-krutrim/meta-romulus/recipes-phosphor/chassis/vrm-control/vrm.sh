#!/bin/sh

vrm-control.sh vdna=0.9 vdnb=0.9
